import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grade-eleven',
  templateUrl: './grade-eleven.component.html',
  styleUrls: ['./grade-eleven.component.css']
})
export class GradeElevenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}


export class Nine {
    name: string = "";
    surname: string = "";
    dob: string = "";
    id_number: number = 0;
    home_address: string = "";
    criminal_record: string = "";
    gender: string = "";
    ethic: string = "";
    nationality: string = "";
    grade: string = "";
}
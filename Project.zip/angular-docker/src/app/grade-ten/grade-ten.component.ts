import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grade-ten',
  templateUrl: './grade-ten.component.html',
  styleUrls: ['./grade-ten.component.css']
})
export class GradeTenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

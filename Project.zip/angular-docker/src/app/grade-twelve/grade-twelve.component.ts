import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grade-twelve',
  templateUrl: './grade-twelve.component.html',
  styleUrls: ['./grade-twelve.component.css']
})
export class GradeTwelveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
